const scene = new THREE.Scene();
scene.background = new THREE.Color(0x27ff9a)

var loader = new THREE.TextureLoader()
loader.load('./Img/fondo.jpg', function(textura) {
    scene.background = textura;
});

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const geometry = new THREE.BoxGeometry(2, 2, 2);

const textureLoader = new THREE.TextureLoader();
const matcap = textureLoader.load('./Img/agua.jpg');
const material = new THREE.MeshMatcapMaterial();
material.matcap = matcap;
material.flatShading = true;

const cube = new THREE.Mesh(geometry, material);
scene.add(cube);
cube.position.set(-2, 0, 0);

const cube1 = new THREE.Mesh(geometry, material);
scene.add(cube1);
cube1.position.set(-6, 0, 0);

const cube2 = new THREE.Mesh(geometry, material);
scene.add(cube2);
cube2.position.set(2, 0, 0);


const cube3 = new THREE.Mesh(geometry, material);
scene.add(cube3);
cube3.position.set(6, 0, 0);

/* control.minDistance = 2;
var control = new THREE.OrbitControls( camera, renderer.domElement );
control.maxDistance = 8; */

//DragControl

const DragControls = new THREE.DragControls([cube, cube1, cube2, cube3], camera, renderer.domElement);
DragControls.deactivate();
DragControls.activate();

DragControls.addEventListener("hoveron", function(event) {
    event.object.material.wireframe = true;
    event.object.scale.y *= 4;
});

DragControls.addEventListener("hoveroff", function(event) {
    event.object.material.wireframe = false;
    event.object.scale.y /= 4;
});

const flycontrols = new THREE.FlyControls(camera, renderer.domElement);
flycontrols.movementSpeed = 50;
flycontrols.rollSpeed = 0.01;
flycontrols.autoForward = false;
flycontrols.dragToLock = false;

camera.position.z = 5;

/* const PointerLockControls = new THREE.PointerLockControls( camera, renderer.domElement );
document.getElementById('btnplay').onclick = ( ) =>  {
    PointerLockControls.lock();
} */

//animacion
function animate() {
    requestAnimationFrame(animate);
    cube.rotation.y += 0.01;
    cube1.rotation.y += 0.01;
    cube2.rotation.y += 0.01;
    cube3.rotation.y += 0.01;;

    flycontrols.update(0.5);

    renderer.render(scene, camera);
}
animate();